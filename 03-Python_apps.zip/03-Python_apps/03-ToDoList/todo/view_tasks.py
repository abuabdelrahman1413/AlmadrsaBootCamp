class ViewTasks:
    @staticmethod
    def main(todo_list):
        todo_list.view_tasks()
