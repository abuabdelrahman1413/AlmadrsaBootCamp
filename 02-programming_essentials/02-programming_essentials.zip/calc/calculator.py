import math
import random2
def add(a, b):
    return a+b

def sub(a, b):
    return a-b

def mult(a, b):
    return a*b

def div(a, b):
    return a/b

def power(a, b):
    return (math.pow(a,b))

def sqr(a):
    return (math.sqrt(a))

def Random(a,b):
    return (random2.randint(a,b))
