# Nearest stars to Earth

stars = ["Sol", "Alpha Centauri", "Barnard", "Wolf 359"]
print(stars[3])

# Highest peak on each tectonic plate
peaks = {
	"African":"Kilimanjaro",
	"Antarctic":"Vinson",
	"Australian":"Puncak Jaya",
	"Eurasian":"Everest",
	"North_American":"Denali",
	"Pcific":"Mauna Kea",
	"South_American":"Aconcagua"
}
print(peaks["Pcific"])