fruits = [
	"apples",
	"bananas",
	"grapes",
	"mangos",
	"nectarines",
	"pears"
]

print("Fruit basket:")

for fruit in fruits:
	if fruit != "nectarines":
		print(fruit)

